package bellmanFord;

public class FloydWarshall {
	public static int[][] path = new int[8][8];
	public static int[][] answer = new int[8][8];

	public static void setDistance(int i, int j, int v) {
		path[i][j] = v;
		path[j][i] = v;
	}

	public static void setPath() {
		for (int i = 0; i < 8; i++)
			path[i][i] = 0;
		setDistance(1, 2, 4);
		setDistance(1, 3, 5);
		setDistance(2, 3, 6);
		setDistance(2, 4, 5);
		setDistance(2, 5, 10);
		setDistance(3, 4, 4);
		setDistance(3, 6, 9);
		setDistance(4, 5, 6);
		setDistance(4, 6, 3);
		setDistance(5, 6, 3);
		setDistance(5, 7, 2);
		setDistance(6, 7, 2);
	}
	
	public static void printAll() {
		for(int i = 1; i < 8; i++) {
			for(int j = 1; j < 8; j++) {
				System.out.print(path[i][j] + "\t");
			}
			System.out.println();
		}
	}
	
	public static void FloydWarshall() {
		for(int i = 1; i < 8; i++) {
			for(int j = 1; j < 8; j++) {
				if(i == j)
					continue;
				int jToi = 0;
				if(path[j][i] != 0)
					jToi = path[j][i];
				else
					break;
				for(int k = 1; k < 8; k++) {
					if(j == k)
						continue;
					if(path[i][k] != 0) {
						if(path[j][k] > jToi + path[i][k])
							path[j][k] = jToi + path[i][k];
						else if(path[j][k] == 0)
							path[j][k] = jToi + path[i][k];
					}
				}
			}
			System.out.println("Select node : " + i);
			printAll();
		}
	}
	
	public static void main(String[] args) {
		for (int i = 1; i < 8; i++) {
			for (int j = 1; j < 8; j++) {
				path[i][j] = 0; // 1000�� �� �� ���� ������ �ǹ��մϴ�.
									// �ʱ� �������� ��� ���� 1000�� �ֽ��ϴ�.
			}
		}
		answer = path;
		setPath(); // �־��� topology�� �����մϴ�.
		FloydWarshall();
	}
}
