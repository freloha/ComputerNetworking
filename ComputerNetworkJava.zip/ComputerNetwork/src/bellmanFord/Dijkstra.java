package bellmanFord;

import java.util.PriorityQueue;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;



public class Dijkstra{
	public static void computePaths(Node source){
		source.shortestDistance=0;

		PriorityQueue<Node> queue = new PriorityQueue<Node>();
		queue.add(source);

		while(!queue.isEmpty()){
			Node u = queue.poll();
			for(Edge e: u.adjacencies){
				Node v = e.target;
				double weight = e.weight;
				double distanceFromU = u.shortestDistance+weight;
				if(distanceFromU<v.shortestDistance){
					queue.remove(v);
					v.shortestDistance = distanceFromU;
					v.parent = u;
					queue.add(v);
				}
			}
		}
	}

	public static List<Node> getShortestPathTo(Node target){
		List<Node> path = new ArrayList<Node>();
		for(Node node = target; node!=null; node = node.parent){
			path.add(node);
		}
		Collections.reverse(path);
		return path;
	}



	public static void main(String[] args){
		Node n1 = new Node("1");
		Node n2 = new Node("2");
		Node n3 = new Node("3");
		Node n4 = new Node("4");
		Node n5 = new Node("5");
		Node n6 = new Node("6");
		Node n7 = new Node("7");

		n1.adjacencies = new Edge[]{
			new Edge(n2,4),
			new Edge(n3,5),
		};

		n2.adjacencies = new Edge[]{
			new Edge(n1,4),
			new Edge(n3,6),
			new Edge(n4,5),
			new Edge(n5,10),
		};

		n3.adjacencies = new Edge[]{
			new Edge(n1,5),
			new Edge(n2,6),
			new Edge(n4,4),
			new Edge(n6,9),
		};

		n4.adjacencies = new Edge[]{
			new Edge(n2,5),
			new Edge(n3,4),
			new Edge(n5,6),
			new Edge(n6,3),
		};

		n5.adjacencies = new Edge[]{
			new Edge(n2,10),
			new Edge(n4,6),
			new Edge(n6,3),
			new Edge(n7,2),
		};

		n6.adjacencies = new Edge[]{
			new Edge(n3,9),
			new Edge(n4,3),
			new Edge(n5,3),
			new Edge(n6,2),
		};

		n7.adjacencies = new Edge[]{
			new Edge(n5,2),
			new Edge(n6,2),
		};

		Node[] nodes = {n1,n2,n3,n4,n5,n6,n7};

		computePaths(n1);
		for(Node n: nodes){
			System.out.println("Distance to " + 
				n + ": " + n.shortestDistance);
    		List<Node> path = getShortestPathTo(n);
    		System.out.println("Path: " + path);
		}

	}


}

class Node implements Comparable<Node>{
	public final String value;
	public Edge[] adjacencies;
	public double shortestDistance = Double.POSITIVE_INFINITY;
	public Node parent;

	public Node(String val){
		value = val;
	}

	public String toString(){
			return value;
	}

	public int compareTo(Node other){
		return Double.compare(shortestDistance, other.shortestDistance);
	}
}

class Edge{
	public final Node target;
	public final double weight;
	public Edge(Node targetNode, double weightVal){
		target = targetNode;
		weight = weightVal;
	}
}