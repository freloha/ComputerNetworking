package bellmanFord;

import java.util.*;
import java.io.*;

public class BellmanFord {
	public static int[][] path = new int[8][8];
	public static int[][] answer = new int[8][8];

	public static void setDistance(int i, int j, int v) {
		path[i][j] = v;
		path[j][i] = v;
	}

	public static void setPath() {
		for (int i = 0; i < 8; i++)
			path[i][i] = 1000;
		setDistance(1, 2, 4);
		setDistance(1, 3, 5);
		setDistance(2, 3, 6);
		setDistance(2, 4, 5);
		setDistance(2, 5, 10);
		setDistance(3, 4, 4);
		setDistance(3, 6, 9);
		setDistance(4, 5, 6);
		setDistance(4, 6, 3);
		setDistance(5, 6, 3);
		setDistance(5, 7, 2);
		setDistance(6, 7, 2);
	}

	public static void bellmanFord(int start) {
		System.out.println("Start in Node " + start);
		int[] upper = { 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000 };
		for (int i = 0; i < 8; i++) {
			int first = 0;
			if (i == 0)
				first = start;
			else if (i == start)
				continue;
			else
				first = i;
			for (int j = i + 2; j < 8; j++) {
				if (i == j)
					continue;
				if (path[first][j] != 1000 && upper[j] > upper[first] + path[first][j]) {
					upper[j] = upper[first] + path[first][j];
				} else if (upper[j] == 1000) {
					upper[j] = path[first][j];
				}
			}
		}
		
		for(int i = start; i < 8; i++)
			answer[start][i] = upper[i];

		for (int i = 1; i < 8; i++) {
			if (i == start)
				continue;
			if (i < start)
				System.out.println(start + " to " + i + " : " + answer[i][start]);
			else
				System.out.println(start + " to " + i + " : " + upper[i]);
		}
	}
	
	public static void main(String[] args) {
		for (int i = 1; i < 8; i++) {
			for (int j = 1; j < 8; j++) {
				path[i][j] = 1000; // 1000�� �� �� ���� ������ �ǹ��մϴ�.
									// �ʱ� �������� ��� ���� 1000�� �ֽ��ϴ�.
			}
		}
		answer = path;
		setPath(); // �־��� topology�� �����մϴ�.

		for (int i = 1; i < 8; i++) {
			for (int j = 1; j < 8; j++) {
				System.out.print(path[i][j] + "\t");
			}
			System.out.println();
		}
		
		System.out.println("----------BellmanFord----------");
		for (int i = 1; i < 8; i++)
			bellmanFord(i);
		
	}
}
